
import React, { useState, useEffect } from 'react';
import { AppView, Notification } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Inventory from './components/Inventory';
import Events from './components/Events';
import FleetMap from './components/FleetMap';
import Churches from './components/Churches';
import QuickAssistant from './components/QuickAssistant';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<AppView>(AppView.DASHBOARD);
  const [notifications, setNotifications] = useState<Notification[]>([
    { id: '1', type: 'info', message: 'Bienvenue sur LOQT Pro. Système en ligne.', time: 'À l\'instant', read: false },
    { id: '2', type: 'warning', message: 'L\'entrepôt A atteint 80% de sa capacité.', time: 'il y a 1h', read: false }
  ]);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      const newNotif: Notification = {
        id: Date.now().toString(),
        type: 'success',
        message: 'Équipement du Tech Summit 2024 vérifié.',
        time: 'À l\'instant',
        read: false
      };
      setNotifications(prev => [newNotif, ...prev]);
    }, 15000);
    return () => clearTimeout(timer);
  }, []);

  const renderView = () => {
    switch (activeView) {
      case AppView.DASHBOARD: return <Dashboard setActiveView={setActiveView} />;
      case AppView.INVENTORY: return <Inventory />;
      case AppView.EVENTS: return <Events />;
      case AppView.MAP: return <FleetMap />;
      case AppView.CHURCHES: return <Churches />;
      case AppView.SETTINGS:
        return (
          <div className="flex items-center justify-center h-[60vh] text-slate-500">
            <div className="text-center animate-in zoom-in duration-300">
              <div className="text-6xl mb-6 grayscale opacity-50">⚙️</div>
              <h2 className="text-2xl font-black text-slate-200 uppercase tracking-widest">Configuration</h2>
              <p className="text-slate-500 mt-2">Gérez les paramètres du cluster LOQT et les nœuds d'API.</p>
              <div className="mt-8 flex gap-4 justify-center">
                <button className="px-6 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-blue-600/20">Paramètres Cloud</button>
                <button className="px-6 py-2 bg-slate-800 border border-slate-700 text-slate-300 rounded-xl text-sm font-bold hover:bg-slate-700">Logs Base de Données</button>
              </div>
            </div>
          </div>
        );
      default: return <Dashboard setActiveView={setActiveView} />;
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="flex bg-slate-950 min-h-screen font-['Inter'] selection:bg-blue-600 selection:text-white">
      <Sidebar activeView={activeView} setActiveView={setActiveView} />
      
      <main className="flex-1 ml-64 min-h-screen p-8 lg:p-12 relative overflow-x-hidden text-slate-200">
        <div className="max-w-7xl mx-auto flex items-center justify-between mb-8 pb-8 border-b border-slate-800">
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-full shadow-sm border border-slate-800 font-medium text-slate-400 hover:text-slate-200 cursor-pointer transition-colors" onClick={() => setActiveView(AppView.DASHBOARD)}>
              <span>🏠</span>
              <span>Accueil</span>
            </div>
            <span className="text-slate-700">/</span>
            <span className="font-black text-blue-500 uppercase tracking-tighter text-lg italic">{activeView}</span>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="hidden lg:flex items-center gap-4 bg-slate-900 border border-slate-800 px-4 py-2 rounded-2xl shadow-sm focus-within:ring-2 focus-within:ring-blue-600/50 transition-all">
              <span className="text-slate-500">🔍</span>
              <input 
                type="text" 
                placeholder="Rechercher ressources, flotte ou église..." 
                className="bg-transparent border-none text-sm outline-none w-64 placeholder:text-slate-600 text-slate-200" 
              />
              <kbd className="text-[10px] bg-slate-800 border border-slate-700 text-slate-500 px-1.5 py-0.5 rounded-md font-sans italic font-black">LOQT-FIND</kbd>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className={`p-3 rounded-2xl transition-all relative ${showNotifications ? 'bg-blue-600 text-white shadow-lg' : 'bg-slate-900 text-slate-400 border border-slate-800 hover:bg-slate-800 shadow-sm'}`}
                >
                  🔔
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-600 rounded-full border-2 border-slate-950 text-[10px] font-bold text-white flex items-center justify-center animate-bounce">
                      {unreadCount}
                    </span>
                  )}
                </button>
                
                {showNotifications && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setShowNotifications(false)}></div>
                    <div className="absolute right-0 mt-4 w-80 bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 z-50 overflow-hidden animate-in slide-in-from-top-2 duration-200">
                      <div className="p-4 bg-slate-950 text-white flex justify-between items-center border-b border-slate-800">
                        <span className="font-bold text-sm">Notifications</span>
                        <button className="text-[10px] uppercase font-bold text-slate-500 hover:text-white" onClick={() => setNotifications(prev => prev.map(n => ({...n, read: true})))}>Tout marquer lu</button>
                      </div>
                      <div className="max-h-96 overflow-y-auto bg-slate-900">
                        {notifications.map(n => (
                          <div key={n.id} className={`p-4 border-b border-slate-800 hover:bg-slate-800 transition-colors ${!n.read ? 'bg-blue-600/10' : ''}`}>
                            <div className="flex gap-3">
                              <span className="text-lg">
                                {n.type === 'warning' ? '⚠️' : n.type === 'error' ? '🚫' : n.type === 'success' ? '✅' : 'ℹ️'}
                              </span>
                              <div>
                                <p className="text-sm font-semibold text-slate-200 leading-tight">{n.message}</p>
                                <p className="text-[10px] text-slate-500 mt-1 uppercase font-bold">{n.time}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                      <button className="w-full py-3 text-center text-xs font-bold text-blue-500 hover:bg-slate-800 transition-colors" onClick={() => setShowNotifications(false)}>Voir le log système</button>
                    </div>
                  </>
                )}
              </div>
              
              <div className="h-10 w-[1px] bg-slate-800 mx-1"></div>
              
              <button className="flex items-center gap-3 p-1 pr-4 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm hover:shadow-md hover:border-slate-700 transition-all group">
                <img src="https://picsum.photos/32/32?grayscale" className="w-8 h-8 rounded-xl object-cover ring-1 ring-slate-800" alt="User" />
                <div className="hidden md:flex flex-col text-left">
                  <span className="text-xs font-bold text-slate-200">Alex Dupont</span>
                  <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">Admin</span>
                </div>
              </button>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto pb-24">
          {renderView()}
        </div>
      </main>

      <QuickAssistant />
    </div>
  );
};

export default App;
