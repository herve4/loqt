
import React from 'react';
import { AppView } from '../types';

interface SidebarProps {
  activeView: AppView;
  setActiveView: (view: AppView) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView }) => {
  const menuItems = [
    { id: AppView.DASHBOARD, label: 'Tableau de bord', icon: '📊' },
    { id: AppView.EVENTS, label: 'Événements', icon: '📅' },
    { id: AppView.CHURCHES, label: 'Églises & Villes', icon: '⛪' },
    { id: AppView.INVENTORY, label: 'Inventaire', icon: '📦' },
    { id: AppView.MAP, label: 'Carte flotte', icon: '🗺️' },
    { id: AppView.SETTINGS, label: 'Configuration', icon: '⚙️' },
  ];

  return (
    <div className="w-64 bg-slate-950 h-screen text-white flex flex-col fixed left-0 top-0 transition-all duration-300 z-50 border-r border-white/5 shadow-2xl">
      <div className="p-8 flex items-center gap-3">
        <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center font-black text-2xl shadow-2xl shadow-blue-500/40 border border-blue-400/20 transform hover:rotate-6 transition-transform">
          L
        </div>
        <div className="flex flex-col">
          <span className="font-black text-xl tracking-tighter leading-none italic">LOQT</span>
          <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest mt-0.5">Logistique</span>
        </div>
      </div>

      <nav className="flex-1 px-4 py-8 overflow-y-auto">
        <p className="px-4 text-[10px] font-black text-slate-600 uppercase tracking-widest mb-4">Système Central</p>
        <ul className="space-y-1.5">
          {menuItems.slice(0, 5).map((item) => (
            <li key={item.id}>
              <button
                onClick={() => setActiveView(item.id)}
                className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all duration-300 group relative overflow-hidden ${
                  activeView === item.id
                    ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/30'
                    : 'text-slate-500 hover:bg-white/5 hover:text-slate-200'
                }`}
              >
                {activeView === item.id && (
                  <div className="absolute left-0 top-0 w-1.5 h-full bg-white/40"></div>
                )}
                <span className={`text-xl transition-transform duration-500 ${activeView === item.id ? 'scale-110' : 'group-hover:scale-125'}`}>{item.icon}</span>
                <span className="font-bold tracking-tight text-sm uppercase">{item.label}</span>
              </button>
            </li>
          ))}
        </ul>

        <p className="px-4 text-[10px] font-black text-slate-600 uppercase tracking-widest mt-12 mb-4">Administration</p>
        <ul className="space-y-1.5">
          <li>
            <button
              onClick={() => setActiveView(AppView.SETTINGS)}
              className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all duration-300 group ${
                activeView === AppView.SETTINGS
                  ? 'bg-white/10 text-white border border-white/10'
                  : 'text-slate-500 hover:bg-white/5 hover:text-slate-200'
              }`}
            >
              <span className="text-xl">⚙️</span>
              <span className="font-bold tracking-tight text-sm uppercase">Config. Cluster</span>
            </button>
          </li>
        </ul>
      </nav>

      <div className="p-6 mt-auto border-t border-white/5 bg-white/5">
        <div className="flex items-center gap-4 p-2">
          <div className="relative">
            <img src="https://picsum.photos/48/48?grayscale" className="w-10 h-10 rounded-xl object-cover ring-2 ring-blue-500/20" alt="Avatar" />
            <span className="absolute -bottom-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-950"></span>
          </div>
          <div className="flex flex-col min-w-0">
            <span className="text-sm font-black truncate leading-none">Alex Dupont</span>
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Super-utilisateur</span>
          </div>
          <button className="ml-auto text-slate-600 hover:text-white transition-colors">🚪</button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
