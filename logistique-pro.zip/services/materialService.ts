
import { Material, PermissionStatus } from '../types';
import { MOCK_MATERIALS } from '../constants';

// Simulation de la Base URL de l'API
const BASE_URL = '/api';

export const materialService = {
  /**
   * GET /materiels/
   * Liste les matériels avec filtres
   */
  async getMateriels(filters: any = {}): Promise<{ results: Material[], count: number }> {
    // Simuler un délai réseau
    await new Promise(resolve => setTimeout(resolve, 500));
    
    let results = [...MOCK_MATERIALS];

    if (filters.searchInput) {
      results = results.filter(m => m.nom.toLowerCase().includes(filters.searchInput.toLowerCase()));
    }
    if (filters.categorie && filters.categorie !== 'All') {
      results = results.filter(m => m.categorie.nom === filters.categorie);
    }
    if (filters.is_deleted !== undefined) {
      results = results.filter(m => m.is_deleted === filters.is_deleted);
    }

    return { results, count: results.length };
  },

  /**
   * GET /materiels/{id}/
   * Détail d'un matériel
   */
  async getMaterielDetail(id: number): Promise<Material> {
    const material = MOCK_MATERIALS.find(m => m.id === id);
    if (!material) throw new Error("Matériel non trouvé");
    return material;
  },

  /**
   * POST /materiel/ajouter/
   * Créer un matériel
   */
  async createMateriel(data: Partial<Material>): Promise<Material> {
    const newMaterial: Material = {
      ...data,
      id: Math.floor(Math.random() * 10000),
      is_deleted: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      images_materiel: data.images_materiel || []
    } as Material;
    // Note: Dans une vraie appli, on ferait un fetch POST ici
    return newMaterial;
  },

  /**
   * PUT /materiels/{id}/update/
   * Mettre à jour
   */
  async updateMateriel(id: number, data: Partial<Material>): Promise<Material> {
    const index = MOCK_MATERIALS.findIndex(m => m.id === id);
    if (index === -1) throw new Error("Matériel non trouvé");
    return { ...MOCK_MATERIALS[index], ...data, updated_at: new Date().toISOString() };
  },

  /**
   * DELETE /materiels/{id}/delete/
   * Soft delete (corbeille)
   */
  async softDelete(id: number): Promise<boolean> {
    return true; // Simulé
  },

  /**
   * POST /materiels/{id}/restore/
   * Restaurer
   */
  async restore(id: number): Promise<boolean> {
    return true; // Simulé
  },

  /**
   * POST /materiels/export/
   * Exporter en Excel
   */
  async exportExcel(data: any[]): Promise<void> {
    console.log("Exportation des données vers Excel...", data);
    // Simuler le téléchargement d'un fichier
    alert("Exportation Excel lancée pour " + data.length + " éléments.");
  },

  /**
   * POST /materiels/demande-permission/
   */
  async requestPermission(reason: string): Promise<{ success: boolean }> {
    return { success: true };
  }
};
